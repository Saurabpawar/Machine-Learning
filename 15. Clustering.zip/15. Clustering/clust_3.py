from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
milk = pd.read_csv("milk.csv",index_col=0)

scaler = StandardScaler()
milkscaled=scaler.fit_transform(milk)

clust = KMeans(n_clusters=3)
clust.fit(milkscaled)
print(clust.labels_)

print(silhouette_score(milkscaled, clust.labels_))

Ks = [2,3,4,5,6,7]
scores = []
for k in Ks:
    clust = KMeans(n_clusters=k)
    clust.fit(milkscaled)
    scores.append(silhouette_score(milkscaled, clust.labels_))    

i_max = np.argmax(scores)
best_k = Ks[i_max]
print("Best Score:", scores[i_max])
print("Best No. of Clusters:", best_k)


clust = KMeans(n_clusters=best_k)
clust.fit(milkscaled)
print(clust.labels_)

milk_clust = milk.copy()
milk_clust['Clust'] = clust.labels_
milk_clust.sort_values('Clust')

# Centroids
milk_clust.groupby('Clust').mean()


##### WSS

clust = KMeans(n_clusters=2)
clust.fit(milkscaled)
print(clust.inertia_)



Ks = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
scores = []
for k in Ks:
    clust = KMeans(n_clusters=k)
    clust.fit(milkscaled)
    scores.append(clust.inertia_)    

plt.scatter(Ks, scores, c='red')
plt.plot(Ks, scores)
plt.xlabel("No. of CLusters")
plt.ylabel("WSS")
plt.title("Scree Plot")
plt.show()


################ USArrests ######################
usa = pd.read_csv("USArrests.csv", index_col=0)
usa_scaled = scaler.fit_transform(usa)


Ks = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
scores = []
for k in Ks:
    clust = KMeans(n_clusters=k)
    clust.fit(usa_scaled)
    scores.append(clust.inertia_)    

plt.scatter(Ks, scores, c='red')
plt.plot(Ks, scores)
plt.xlabel("No. of CLusters")
plt.ylabel("WSS")
plt.title("Scree Plot")
plt.show()











