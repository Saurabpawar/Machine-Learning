from sklearn.cluster import DBSCAN
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
milk = pd.read_csv("milk.csv",index_col=0)

scaler = StandardScaler()
milkscaled=scaler.fit_transform(milk)

clust = DBSCAN(eps=2, min_samples=6)
clust.fit(milkscaled)
print(clust.labels_)

milkscaled = pd.DataFrame(milkscaled, 
                          columns=milk.columns)
milk_clust = milkscaled.copy()
milk_clust['Clust'] = clust.labels_
milk_clust_wo = milk_clust[milk_clust['Clust']>-1]

print(silhouette_score(milk_clust_wo.iloc[:,:-1],
                       milk_clust_wo['Clust']))

############# loop for tuning ########################
milkscaled=scaler.fit_transform(milk)
milkscaled = pd.DataFrame(milkscaled, 
                          columns=milk.columns)
epsilons = [0.5, 0.8, 1, 1.5]
min_pts = [3,2,4]
params = []
for e in epsilons:
    for m in min_pts:
        clust = DBSCAN(eps=e, min_samples=m)
        clust.fit(milkscaled)
        milk_clust = milkscaled.copy()
        milk_clust['Clust'] = clust.labels_
        milk_clust_wo = milk_clust[milk_clust['Clust']>-1]
        if len(milk_clust_wo['Clust'].unique()) > 1:
            score = silhouette_score(milk_clust_wo.iloc[:,:-1],
                                   milk_clust_wo['Clust'])
            params.append([e,m,score])

pd_results = pd.DataFrame(params,columns=['eps','min','score'])

############# USArrests #################
usa = pd.read_csv("USArrests.csv", index_col=0)
usa_scaled = scaler.fit_transform(usa)


usa_scaled = pd.DataFrame(usa_scaled, 
                          columns=usa.columns)
epsilons = [0.5, 0.8, 1, 1.5]
min_pts = [3,2,4]
params = []
for e in epsilons:
    for m in min_pts:
        clust = DBSCAN(eps=e, min_samples=m)
        clust.fit(usa_scaled)
        usa_clust = usa_scaled.copy()
        usa_clust['Clust'] = clust.labels_
        usa_clust_wo = usa_clust[usa_clust['Clust']>-1]
        if len(usa_clust_wo['Clust'].unique()) > 1:
            score = silhouette_score(usa_clust_wo.iloc[:,:-1],
                                   usa_clust_wo['Clust'])
            params.append([e,m,score])

pd_results = pd.DataFrame(params,columns=['eps','min','score'])



