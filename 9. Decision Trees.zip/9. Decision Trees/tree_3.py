import pandas as pd 
from sklearn.tree import DecisionTreeRegressor, plot_tree
import matplotlib.pyplot as plt 
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV 
from sklearn.model_selection import KFold 
from sklearn.metrics import r2_score , mean_squared_error
import numpy as np

boston = pd.read_csv("Boston.csv")
X = boston.drop('medv', axis=1)
y = boston['medv']
X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               random_state=23)
dtr = DecisionTreeRegressor(random_state=23, max_depth=2)
dtr.fit(X_train, y_train)
y_pred = dtr.predict(X_test)
print(r2_score(y_test, y_pred))

### plotting the tree
plt.figure(figsize=(30,15))
plot_tree(dtr,feature_names=list(X.columns),
               filled=True, fontsize=20) 
plt.show()

params = {'min_samples_split':[2, 5, 10 , 20,60, 80, 100],
          'max_depth': [3,4,5,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}
dtr = DecisionTreeRegressor(random_state=23)
kfold = KFold(n_splits=5, shuffle=True, random_state=23)
gcv = GridSearchCV(dtr, param_grid=params, cv=kfold,
                   scoring='r2',verbose=3)
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

