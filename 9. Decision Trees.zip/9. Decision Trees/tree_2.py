import pandas as pd 
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
import numpy as np
from sklearn.model_selection import GridSearchCV 
from sklearn.model_selection import StratifiedKFold 
from sklearn.preprocessing import LabelEncoder 

glass = pd.read_csv("Glass.csv")
X = glass.drop('Type', axis=1)
y = glass['Type']

le = LabelEncoder()
le_y = le.fit_transform(y)
print(le.classes_)

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
params = {'min_samples_split':[2, 5, 10 , 20,60, 80, 100],
          'max_depth': [3,4,5,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}
dtc = DecisionTreeClassifier(random_state=23)
gcv = GridSearchCV(dtc, param_grid=params, cv=kfold,
                   scoring='neg_log_loss')
gcv.fit(X, le_y)
print(gcv.best_params_)
print(gcv.best_score_)

## Plotting the best tree
bm_tree = gcv.best_estimator_
plt.figure(figsize=(30,15))
plot_tree(bm_tree,feature_names=list(X.columns),
               class_names=list(le.classes_),
               filled=True, fontsize=20) 
plt.show()

### Inferencing
tst_glass = pd.read_csv("tst_Glass.csv")
predictions = bm_tree.predict(tst_glass)
print(predictions)

le.inverse_transform(predictions)


