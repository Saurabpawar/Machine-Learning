import pandas as pd 
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import ConfusionMatrixDisplay
import numpy as np
import os
os.chdir("D:\CDAC DBDA\Advance Analytics\Datasets")

hr = pd.read_csv("HR_comma_sep.csv")
dum_hr = pd.get_dummies(hr, drop_first=True)
X = dum_hr.drop('left', axis=1)
y = dum_hr['left']

X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)
dtc = DecisionTreeClassifier(random_state=23, max_depth=2)
dtc.fit(X_train, y_train)

plt.figure(figsize=(10,8))
plot_tree(dtc,feature_names=list(X.columns),
               class_names=['Working','Left'],
               filled=True, fontsize=11) 
plt.show()

y_pred = dtc.predict(X_test)
y_pred_prob = dtc.predict_proba(X_test)


### Training set accuracy
y_pred_trn = dtc.predict(X_train)
print(accuracy_score(y_train, y_pred_trn))


################# Grid Search CV  @@@@@@@@@@@@@@@@@@@
from sklearn.model_selection import GridSearchCV 
from sklearn.model_selection import StratifiedKFold 
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
params = {'min_samples_split':[2, 5, 10 , 20,60, 80, 100],
          'max_depth': [3,4,5,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}
dtc = DecisionTreeClassifier(random_state=23)
gcv = GridSearchCV(dtc, param_grid=params, cv=kfold,
                   scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)
pd_cv = gcv.cv_results_

#### train test split with Grid Search CV ###########

X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.15,
                               stratify=y,
                               random_state=23)
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
## with default params
params ={}
dtc = DecisionTreeClassifier(random_state=23)
gcv_default = GridSearchCV(dtc, param_grid=params, cv=kfold,
                   scoring='neg_log_loss')
gcv_default.fit(X_train, y_train)
pd_cv = pd.DataFrame( gcv_default.cv_results_ )
print(gcv_default.best_params_)
print(gcv_default.best_score_)

dtc.fit(X_train, y_train)
y_pred_prob = dtc.predict_proba(X_test)
print(log_loss(y_test, y_pred_prob))

## with spec params
params = {'min_samples_split':[2, 5, 10 , 20,60, 80, 100],
          'max_depth': [3,4,5,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}
dtc = DecisionTreeClassifier(random_state=23)
gcv = GridSearchCV(dtc, param_grid=params, cv=kfold,
                   scoring='neg_log_loss')
gcv.fit(X_train, y_train)
print(gcv.best_params_)
print(gcv.best_score_)
bm = gcv.best_estimator_
y_pred_prob = bm.predict_proba(X_test)
print(log_loss(y_test, y_pred_prob))





#################################################
kyph = pd.read_csv("Kyphosis.csv")
y = kyph['Kyphosis']
X = kyph.drop('Kyphosis', axis=1)

X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)
dtc = DecisionTreeClassifier(random_state=23, max_depth=5)
dtc.fit(X_train, y_train)

plt.figure(figsize=(20,15))
plot_tree(dtc,feature_names=list(X.columns),
               class_names=['absent','present'],
               filled=True, fontsize=11) 
plt.show()

y_pred = dtc.predict(X_test)
y_pred_prob = dtc.predict_proba(X_test)

print(accuracy_score(y_test, y_pred))

params = {'min_samples_split':[2, 5, 10 , 20],
          'max_depth': [3,4,5,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}
dtc = DecisionTreeClassifier(random_state=23)
gcv = GridSearchCV(dtc, param_grid=params, cv=kfold,
                   scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

## Plotting the best tree
bm_tree = gcv.best_estimator_
plt.figure(figsize=(20,15))
plot_tree(bm_tree,feature_names=list(X.columns),
               class_names=['absent','present'],
               filled=True, fontsize=20) 
plt.show()


