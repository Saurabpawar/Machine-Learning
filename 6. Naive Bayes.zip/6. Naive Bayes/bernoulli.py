import pandas as pd 
from  sklearn.naive_bayes import BernoulliNB
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import ConfusionMatrixDisplay
import numpy as np

cancer = pd.read_csv("Cancer.csv", index_col=0)
dum_canc = pd.get_dummies(cancer, drop_first=True)
X = dum_canc.drop('Class_recurrence-events', axis=1).values
y = dum_canc['Class_recurrence-events'].values
X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)
nb = BernoulliNB()
nb.fit(X_train, y_train)
y_pred = nb.predict(X_test)
y_pred_prob = nb.predict_proba(X_test)
print(accuracy_score(y_test, y_pred))
print(log_loss(y_test, y_pred_prob))
