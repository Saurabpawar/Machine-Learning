import pandas as pd 
from sklearn.svm import SVC
import matplotlib.pyplot as plt 
from sklearn.model_selection import StratifiedKFold
import numpy as np
from sklearn.model_selection import GridSearchCV

satellite = pd.read_csv("Satellite.csv", sep=';')
X = satellite.drop('classes', axis=1)
y = satellite['classes']


svm = SVC(kernel='rbf')
params = {'C': np.linspace(0.0001, 10, 20),
          'gamma': np.linspace(0.001, 5, 10),
          'decision_function_shape':['ovo','ovr']}
kfold = StratifiedKFold(n_splits=5, shuffle=True, 
                        random_state=23)
svm = SVC(kernel='rbf')
gcv = GridSearchCV(svm, param_grid=params,cv=kfold)
gcv.fit(X,y)

print(gcv.best_params_)
print(gcv.best_score_)
