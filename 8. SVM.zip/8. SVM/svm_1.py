import pandas as pd 
from sklearn.svm import SVC
import matplotlib.pyplot as plt 
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.metrics import log_loss
from sklearn.metrics import ConfusionMatrixDisplay
import numpy as np
from sklearn.model_selection import GridSearchCV

brupt = pd.read_csv("Bankruptcy.csv", index_col=0)
X = brupt.drop(['D', 'YR'], axis=1)
y = brupt['D']

X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)

svm = SVC(kernel='linear',probability=True)
svm.fit(X_train, y_train)
y_pred = svm.predict(X_test)
print(accuracy_score(y_test, y_pred))

y_pred_prob = svm.predict_proba(X_test)
print(log_loss(y_test, y_pred_prob))
#################################
params = {'C': np.linspace(0.0001, 10, 20)}
kfold = StratifiedKFold(n_splits=5, shuffle=True, 
                        random_state=23)
svm = SVC(kernel='linear',probability=True, random_state=23)
gcv = GridSearchCV(svm, param_grid=params,cv=kfold,
                   scoring='neg_log_loss')
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)
pd_cv = pd.DataFrame( gcv.cv_results_ ) 


# Accuracy
kfold = StratifiedKFold(n_splits=5, shuffle=True, 
                        random_state=23)
svm = SVC(kernel='linear')
gcv = GridSearchCV(svm, param_grid=params,cv=kfold)
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)
pd_cv = pd.DataFrame( gcv.cv_results_ ) 

### Polynomial

svm = SVC(kernel='poly',degree=2)
svm.fit(X_train, y_train)
y_pred = svm.predict(X_test)
print(accuracy_score(y_test, y_pred))
### Grid search
params = {'C': np.linspace(0.0001, 10, 20),
          'coef0': np.linspace(0, 5, 10),
          'degree': [2,3]}
kfold = StratifiedKFold(n_splits=5, shuffle=True, 
                        random_state=23)
svm = SVC(kernel='poly')
gcv = GridSearchCV(svm, param_grid=params,cv=kfold)
gcv.fit(X,y)

print(gcv.best_params_)
print(gcv.best_score_)
pd_cv = pd.DataFrame( gcv.cv_results_ ) 

#### Radial

svm = SVC(kernel='rbf')
svm.fit(X_train, y_train)
y_pred = svm.predict(X_test)
print(accuracy_score(y_test, y_pred))

### Grid Search
params = {'C': np.linspace(0.0001, 10, 20),
          'gamma': np.linspace(0.001, 5, 10)}
kfold = StratifiedKFold(n_splits=5, shuffle=True, 
                        random_state=23)
svm = SVC(kernel='rbf')
gcv = GridSearchCV(svm, param_grid=params,cv=kfold)
gcv.fit(X,y)

print(gcv.best_params_)
print(gcv.best_score_)
