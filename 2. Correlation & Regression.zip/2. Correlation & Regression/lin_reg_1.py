import pandas as pd 
import numpy as np 
from sklearn.linear_model import LinearRegression 
import matplotlib.pyplot as plt 

x = np.array([3,5,6,1,7,8,9,10])
r = np.array([0.1, -0.2, 0.3, 0.4, 0.9, 1.2, -1.3, 1])
y = 3*x + 5
x = x+r
np.corrcoef(x,y)
lr = LinearRegression()
lr.fit(x.reshape(-1, 1), y)
print(lr.intercept_)
print(lr.coef_)

ycap = 2.76805098*x + 5.590272428041182
plt.scatter(x, y)
plt.plot(x, ycap, c='red')
plt.show()

##########################################
pizza = pd.read_csv("pizza.csv")
x = pizza['Promote'].values
y = pizza['Sales'].values 

lr = LinearRegression()
lr.fit(x.reshape(-1, 1), y)
print(lr.intercept_)
print(lr.coef_)

#ycap = 23.50640302*x + 5.4858653632529695
plt.scatter(x, y)
plt.plot(x, ycap, c='red')
plt.show()

vals = np.array([75, 50, 40])
### Applying the equation
y_pred = lr.predict(vals.reshape(-1, 1))
print(y_pred)

################ insure #############
insure = pd.read_csv("Insure_auto.csv", index_col=0)
X = insure[['Home','Automobile']].values 
y = insure['Operating_Cost'].values

lr = LinearRegression()
lr.fit(X, y)
print(lr.intercept_)
print(lr.coef_)

vals = np.array([[100, 500],
                 [200, 700],
                 [500, 200]])

y_pred = lr.predict(vals)
print(y_pred)

###################################
boston = pd.read_csv("Boston.csv")
x = boston['crim'].values
y = boston['medv'].values 

lr = LinearRegression()
lr.fit(x.reshape(-1, 1), y)
print(lr.intercept_)
print(lr.coef_)
print(boston['crim'].corr(boston['medv']))

ycap = lr.predict(x.reshape(-1, 1))
plt.scatter(x, y)
plt.plot(x, ycap, c='red')
plt.show()

# MSE
print(np.mean((y-ycap)**2))
# or
print(np.sum((y-ycap)**2)/506)
# or
from sklearn.metrics import mean_squared_error as mse
print(mse(y, ycap))

# MAE
print( np.mean( np.absolute(y-ycap) ) )
# OR
from sklearn.metrics import mean_absolute_error as mae
print(mae(y, ycap))

# R2
print( 1 - (np.sum((y-ycap)**2))/np.sum((y-y.mean())**2))
# or
from sklearn.metrics import r2_score 
print(r2_score(y, ycap))

################ insure #############
insure = pd.read_csv("Insure_auto.csv", index_col=0)
x1 = insure['Home'].values 
x2 = insure['Automobile'].values
y = insure['Operating_Cost'].values

lr1 = LinearRegression()
lr1.fit(x1.reshape(-1, 1), y)
ycap = lr1.predict(x1.reshape(-1, 1))
print(mse(y, ycap))
print(mae(y, ycap))

lr2 = LinearRegression()
lr2.fit(x2.reshape(-1, 1), y)
ycap = lr2.predict(x2.reshape(-1, 1))
print(mse(y, ycap))
print(mae(y, ycap))

X = insure[['Home','Automobile']].values
y = insure['Operating_Cost'].values
lr = LinearRegression()
lr.fit(X, y)
ycap = lr.predict(X)
print(mse(y, ycap))
print(mae(y, ycap))

