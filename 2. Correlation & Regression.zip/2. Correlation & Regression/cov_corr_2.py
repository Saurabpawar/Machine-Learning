import numpy as np 
import matplotlib.pyplot as plt 
import pandas as pd
import seaborn as sns 

insure = pd.read_csv("Insure_auto.csv", index_col=0)
insure.corr()

## Matrix Plot / Scatter Matrix Plot
sns.pairplot(data=insure)
plt.show()

## Heatmap
sns.heatmap(data=insure.corr(), annot=True)
plt.show()

boston = pd.read_csv("Boston.csv")
## Heatmap
sns.heatmap(data=boston.corr())
plt.show()

