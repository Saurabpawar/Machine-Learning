import pandas as pd 
from sklearn.linear_model import LinearRegression 
from sklearn.metrics import r2_score 
from sklearn.model_selection import train_test_split

insure = pd.read_csv("Insure_auto.csv", index_col=0)

# ins_train = insure.iloc[[1,4,5,7,2,9,3],:]
# ins_test = insure.iloc[[6,0,8],:]
ins_train, ins_test = train_test_split(insure,test_size=0.3,
                                       random_state=23)

X_train = ins_train[['Home','Automobile']].values
y_train = ins_train['Operating_Cost'].values
X_test = ins_test[['Home','Automobile']].values
y_test = ins_test['Operating_Cost'].values

print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)

lr = LinearRegression()
lr.fit(X_train, y_train)
y_pred = lr.predict(X_test)
print(r2_score(y_test, y_pred))
