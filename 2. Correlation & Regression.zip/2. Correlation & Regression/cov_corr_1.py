import numpy as np 
import matplotlib.pyplot as plt 
import pandas as pd
x = np.array([2,4,5,7,8,9,10,12])
y = np.array([45, 67, 89, 123, 156, 189, 201, 234])

plt.scatter(x, y)
plt.show()

print(np.corrcoef(x,y))

x = np.array([2, 8, 19, 34, 56, 54, 89, 45])
y = np.array([45, 67, 89, 123, 156, 189, 201, 234])

plt.scatter(x, y)
plt.show()
print(np.corrcoef(x,y))
###############################################

x = np.array([2,4,5,7,8,9,10,12])
y = np.array([234, 201, 189, 156, 123, 89, 67, 45])

plt.scatter(x, y)
plt.show()


print(np.corrcoef(x,y))

##############################################
pizza = pd.read_csv("pizza.csv")
x = pizza['Promote']
y = pizza['Sales']

plt.scatter(x, y)
plt.show()

print(np.corrcoef(x,y))

###################################################

boston = pd.read_csv("Boston.csv")
x = boston['lstat']
y = boston['medv']


plt.scatter(x, y)
plt.show()

print(np.corrcoef(x,y))

############################################

diamonds = pd.read_csv("diamonds.csv")
x = diamonds['carat']
y = diamonds['price']


plt.scatter(x, y)
plt.show()

print(np.corrcoef(x,y))

##############################################
sals = pd.read_csv("Salaries.csv")
x = sals['yrs.since.phd']
y = sals['salary']

plt.scatter(x, y)
plt.show()

print(np.corrcoef(x,y))
