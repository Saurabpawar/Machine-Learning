import pandas as pd 
import numpy as np 
from sklearn.linear_model import LinearRegression 
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

boston = pd.read_csv("Boston.csv")

# X = boston.drop('medv', axis=1)
# y = boston['medv']

# lr = LinearRegression()
# lr.fit(X, y)
# print(lr.intercept_) # bo
# print(lr.coef_) # b1, b2,   
bs_train, bs_test = train_test_split(boston, test_size=0.3,
                                     random_state=23)
X_train = bs_train.drop('medv', axis=1)
y_train = bs_train['medv']
X_test = bs_test.drop('medv', axis=1)
y_test = bs_test['medv']

lr = LinearRegression()
lr.fit(X_train, y_train)
y_pred = lr.predict(X_test)
print(r2_score(y_test, y_pred))

# Step-Wise
cols = boston.columns[:-1] 

for i in range(1,len(cols)+1):
    X_train = bs_train[cols[:i]]
    y_train = bs_train['medv']
    X_test = bs_test[cols[:i]]
    y_test = bs_test['medv']

    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_pred = lr.predict(X_test)
    print(r2_score(y_test, y_pred))

################################################
diamonds = pd.read_csv("Diamonds.csv")

dum_dia = pd.get_dummies(diamonds, drop_first=True)

dia_train, dia_test = train_test_split(dum_dia, test_size=0.3,
                                     random_state=23)
X_train = dia_train.drop('price', axis=1)
y_train = dia_train['price']
X_test = dia_test.drop('price', axis=1)
y_test = dia_test['price']

lr = LinearRegression()
lr.fit(X_train, y_train)
y_pred = lr.predict(X_test)
print(r2_score(y_test, y_pred))

################################################
sals = pd.read_csv("Salaries.csv")
dum_sals = pd.get_dummies(sals, drop_first=True)

sal_train, sal_test = train_test_split(dum_sals, test_size=0.3,
                                     random_state=23)
X_train = sal_train.drop('salary', axis=1)
y_train = sal_train['salary']
X_test = sal_test.drop('salary', axis=1)
y_test = sal_test['salary']

lr = LinearRegression()
lr.fit(X_train, y_train)
y_pred = lr.predict(X_test)
print(r2_score(y_test, y_pred))

