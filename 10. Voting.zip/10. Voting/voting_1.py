import pandas as pd 
from sklearn.linear_model import LogisticRegression 
from sklearn.naive_bayes import GaussianNB 
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import VotingClassifier
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
import numpy as np
from sklearn.pipeline import Pipeline

hr = pd.read_csv("HR_comma_sep.csv")
dum_hr = pd.get_dummies(hr, drop_first=True)
X = dum_hr.drop('left', axis=1)
y = dum_hr['left']

X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)
lr = LogisticRegression()
mm_scaler = MinMaxScaler()
knn = KNeighborsClassifier()
pipe_knn = Pipeline([('SCL', mm_scaler),('KNN', knn)])
nb = GaussianNB()

voting = VotingClassifier([('LR',lr),('P_KNN',pipe_knn),
                           ('NB',nb)], voting='soft')
voting.fit(X_train, y_train)
y_pred = voting.predict(X_test)
print(accuracy_score(y_test, y_pred))
y_pred_prob = voting.predict_proba(X_test)
print(log_loss(y_test, y_pred_prob))


################# Grid Search CV  @@@@@@@@@@@@@@@@@@@
from sklearn.model_selection import GridSearchCV 
from sklearn.model_selection import StratifiedKFold 
kfold = StratifiedKFold(n_splits=5, shuffle=True, 
                        random_state=23)
print(voting.get_params())
params = {'LR__penalty':['l1','l2','elasticnet',None],
          'P_KNN__KNN__n_neighbors':[3,5,7],
          'NB__var_smoothing': np.linspace(1e-9, 1, 20)}
gcv = GridSearchCV(voting, param_grid=params, cv=kfold,
                   scoring='neg_log_loss', verbose=2)
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)


