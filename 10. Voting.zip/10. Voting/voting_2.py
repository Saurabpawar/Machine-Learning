import pandas as pd 
from sklearn.linear_model import ElasticNet
from sklearn.neighbors import KNeighborsRegressor 
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import VotingRegressor
from sklearn.tree import DecisionTreeRegressor
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import numpy as np
from sklearn.pipeline import Pipeline

boston = pd.read_csv("Boston.csv")
X = boston.drop('medv', axis=1).values
y = boston['medv'].values
X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               random_state=23)

elastic = ElasticNet()
mm_scaler = MinMaxScaler()
knn = KNeighborsRegressor()
pipe_knn = Pipeline([('SCL', mm_scaler),('KNN', knn)])
dtr = DecisionTreeRegressor(random_state=23)

voting = VotingRegressor([('LR',elastic),('P_KNN',pipe_knn),
                           ('TREE',dtr)])
voting.fit(X_train, y_train)
y_pred = voting.predict(X_test)
print(r2_score(y_test, y_pred))

### weighted

voting = VotingRegressor([('LR',elastic),('P_KNN',pipe_knn),
                           ('TREE',dtr)],
                         weights=[0.1, 0.3, 0.6])
voting.fit(X_train, y_train)
y_pred = voting.predict(X_test)
print(r2_score(y_test, y_pred))

################# Grid Search CV  @@@@@@@@@@@@@@@@@@@
from sklearn.model_selection import GridSearchCV 
from sklearn.model_selection import KFold 
kfold = KFold(n_splits=5, shuffle=True, 
                        random_state=23)
print(voting.get_params())
params = {'LR__alpha':[0.001, 1, 2],
          'LR__l1_ratio':[0.001, 0.5, 1],
          'P_KNN__KNN__n_neighbors':[3,5,7],
          'TREE__max_depth': [None, 3, 6]}
gcv = GridSearchCV(voting, param_grid=params, cv=kfold,
                   verbose=2)
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)


