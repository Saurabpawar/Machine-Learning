import pandas as pd 
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt 
from sklearn.metrics import accuracy_score
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
import numpy as np 

hr = pd.read_csv("HR_comma_sep.csv")
dum_hr = pd.get_dummies(hr, drop_first=True)
X = dum_hr.drop('left', axis=1)
y = dum_hr['left']

rf = RandomForestClassifier(random_state=23,oob_score=True,
                            n_estimators=20)

X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)
rf.fit(X_train, y_train)
print("Out of Bag Score =", rf.oob_score_)

y_pred = rf.predict(X_test)
print(accuracy_score(y_test, y_pred))

############## Grid Seach CV ##################

params = {'max_features':[2,4,6,8,10],
          'min_samples_split':[2, 5, 20, 80, 100],
          'max_depth': [3,4,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}

kfold = StratifiedKFold(n_splits=5, 
                        shuffle=True, random_state=23)
gcv = GridSearchCV(rf, param_grid=params,verbose=2,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)
bm_rf = gcv.best_estimator_
########### Individual tree ################
from sklearn.tree import DecisionTreeClassifier
params = {'min_samples_split':[2, 5, 20, 80, 100],
          'max_depth': [3,4,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}
dtc = DecisionTreeClassifier(random_state=23)
kfold = StratifiedKFold(n_splits=5, 
                        shuffle=True, random_state=23)
gcv = GridSearchCV(dtc, param_grid=params,verbose=3,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)
bm_tree = gcv.best_estimator_

############### Importances Plot ################
print(bm_tree.feature_importances_)
df_imp = pd.DataFrame({'Features':list(X.columns),
                       'Importance':bm_tree.feature_importances_})
df_imp = df_imp[df_imp['Importance']>0].sort_values('Importance')
plt.barh(df_imp['Features'],df_imp['Importance'])
plt.title("Tree")
plt.show()


df_imp = pd.DataFrame({'Features':list(X.columns),
                       'Importance':bm_rf.feature_importances_})
df_imp = df_imp[df_imp['Importance']>0].sort_values('Importance')
plt.barh(df_imp['Features'],df_imp['Importance'])
plt.title("Random Forest")
plt.show()





