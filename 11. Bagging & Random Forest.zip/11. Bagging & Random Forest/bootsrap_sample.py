import numpy as np
v = np.arange(1,11 )

np.random.choice(v, size=5, replace=False)

# Bootstrap Sample
np.random.choice(v, size=10, replace=True)