import pandas as pd 
from sklearn.linear_model import LogisticRegression 
from sklearn.naive_bayes import GaussianNB 
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import BaggingClassifier
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
import numpy as np


hr = pd.read_csv("HR_comma_sep.csv")
dum_hr = pd.get_dummies(hr, drop_first=True)
X = dum_hr.drop('left', axis=1)
y = dum_hr['left']

X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)
lr = LogisticRegression()

bagg = BaggingClassifier(lr, n_estimators=15,
                         random_state=23)
bagg.fit(X_train, y_train)
y_pred = bagg.predict(X_test)
print(accuracy_score(y_test, y_pred))
y_pred_prob = bagg.predict_proba(X_test)
print(log_loss(y_test, y_pred_prob))

############## Grid Search #################
from sklearn.model_selection import StratifiedKFold 
from sklearn.model_selection import GridSearchCV

kfold = StratifiedKFold(n_splits=5, 
                        shuffle=True, random_state=23)
print(bagg.get_params())
bagg = BaggingClassifier(lr, n_estimators=15,
                         random_state=23)
params = {'estimator__penalty':['l1','l2','elasticnet',None]}
gcv = GridSearchCV(bagg, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

#### Indivdual logistic
params = {'penalty':['l1','l2','elasticnet',None]}
gcv = GridSearchCV(lr, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

### Individual Tree
from sklearn.tree import DecisionTreeClassifier
dtc = DecisionTreeClassifier(random_state=23)
params = {'min_samples_split':[2, 5, 20, 80, 100],
          'max_depth': [3,4,6,7,None],
          'min_samples_leaf':[1, 5, 10, 20]}

gcv = GridSearchCV(dtc, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

## Bagging with tree
bagg = BaggingClassifier(dtc, n_estimators=15,
                         random_state=23)
params = {'estimator__min_samples_split':[2, 5, 20, 80, 100],
          'estimator__max_depth': [3,4,6,7,None],
          'estimator__min_samples_leaf':[1, 5, 10, 20]}
gcv = GridSearchCV(bagg, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

#######################################
from sklearn.model_selection import cross_val_score 
dtc = DecisionTreeClassifier(random_state=23)
bagg = BaggingClassifier(dtc, n_estimators=15,
                         random_state=23)
results = cross_val_score(bagg, X, y, cv=kfold,
                          scoring='neg_log_loss')
print(results.mean())


