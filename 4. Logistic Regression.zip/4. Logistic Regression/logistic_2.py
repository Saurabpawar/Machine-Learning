import pandas as pd 
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

import numpy as np

glass = pd.read_csv("Glass.csv")
X = glass.drop('Type', axis=1)
y = glass['Type']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,
                               stratify=y,
                               random_state=23)

lr = LogisticRegression(multi_class='multinomial')
lr.fit(X_train, y_train)
print(lr.coef_)
print(lr.intercept_)

y_pred = lr.predict(X_test)
print(accuracy_score(y_test, y_pred))  

from sklearn.metrics import confusion_matrix 
from sklearn.metrics import ConfusionMatrixDisplay
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(cm,
                              display_labels=y_test.unique())
disp.plot()
plt.xticks(rotation=90)
plt.show()

from sklearn.metrics import classification_report 
print(classification_report(y_test, y_pred))

################################
from sklearn.model_selection import StratifiedKFold 
from sklearn.model_selection import GridSearchCV
lr = LogisticRegression()

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
params = {'penalty': ['l1', 'l2', 'elasticnet', None],
          'l1_ratio': np.linspace(0,1,5),
          'solver':['lbfgs','liblinear',
                   'newton-cg','newton-cholesky','sag','saga'],
          'multi_class':['ovr', 'multinomial']}
#gcv = GridSearchCV(lr, param_grid=params,cv=kfold,
#                   scoring='f1_macro')
### Tuning with log loss
gcv = GridSearchCV(lr, param_grid=params,cv=kfold,
                    scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)
