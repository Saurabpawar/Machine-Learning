import pandas as pd 
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt 
from sklearn.metrics import accuracy_score
import numpy as np
from sklearn.model_selection import StratifiedKFold 
from sklearn.model_selection import GridSearchCV

img_seg = pd.read_csv("Image_Segmention.csv")
X = img_seg.drop('Class', axis=1)
y = img_seg['Class']

lr = LogisticRegression()

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
params = {'penalty': ['l1', 'l2', 'elasticnet', None],
          'l1_ratio': np.linspace(0,1,5),
          'solver':['lbfgs','liblinear',
                   'newton-cg','newton-cholesky','sag','saga'],
          'multi_class':['ovr', 'multinomial']}

### Tuning with log loss
gcv = GridSearchCV(lr, param_grid=params,cv=kfold,
                    scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)
