import pandas as pd 
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import ConfusionMatrixDisplay
import numpy as np
hr = pd.read_csv("HR_comma_sep.csv")
dum_hr = pd.get_dummies(hr, drop_first=True)
print(hr['left'].value_counts())
print(hr['left'].value_counts(normalize=True)*100)

train, test = train_test_split(dum_hr, test_size=0.3,
                               stratify=hr['left'],
                               random_state=23)
 X_train = train.drop('left', axis=1)
y_train = train['left']
X_test = test.drop('left', axis=1)
y_test = test['left']

print(y_train.value_counts(normalize=True)*100)
print(y_test.value_counts(normalize=True)*100)

lr = LogisticRegression()
lr.fit(X_train, y_train)
print(lr.coef_)
print(lr.intercept_)

y_pred = lr.predict(X_test)


## ROC 
from sklearn.metrics import roc_curve, roc_auc_score

y_pred_prob = lr.predict_proba(X_test)
y_pred_prob = y_pred_prob[:,1]
op = roc_curve(y_test, y_pred_prob)
fpr, tpr, thres = op

plt.plot(fpr, tpr)
plt.scatter(fpr, tpr, c='red')
plt.xlabel("1 - Specificity")
plt.ylabel("Sensitivity")
plt.show()

## Area Under the Curve
print(roc_auc_score(y_test, y_pred_prob))
# acu_count = 0
# for i in range(0, len(y_pred)):
#     if y_pred[i] == y_test.values[i]:
#         acu_count += 1
# print("Accuracy Score =", acu_count/len(y_pred))       
# OR
print(accuracy_score(y_test, y_pred))   

print(confusion_matrix(y_test, y_pred))
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(cm,display_labels=[0,1])
disp.plot()
plt.show()
## Recall
from sklearn.metrics import recall_score
print(recall_score(y_test, y_pred, pos_label=1))
print(recall_score(y_test, y_pred, pos_label=0))

## Precision
from sklearn.metrics import precision_score 
print(precision_score(y_test, y_pred, pos_label=1))
print(precision_score(y_test, y_pred, pos_label=0))

## F1-Score
from sklearn.metrics import f1_score
print(f1_score(y_test, y_pred, pos_label=1))
print(f1_score(y_test, y_pred, pos_label=0))

from sklearn.metrics import classification_report 
print(classification_report(y_test, y_pred))



## Log Loss
from sklearn.metrics import log_loss 
y_pred_prob = lr.predict_proba(X_test)
print(log_loss(y_test, y_pred_prob))

################# GridSearch
from sklearn.model_selection import StratifiedKFold 
from sklearn.model_selection import GridSearchCV
lr = LogisticRegression()
X = dum_hr.drop('left', axis=1)
y = dum_hr['left']
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
params = {'penalty': ['l1', 'l2', 'elasticnet', None],
          'l1_ratio': np.linspace(0,1,5),
          'solver':['lbfgs','liblinear',
                   'newton-cg','newton-cholesky','sag','saga']}
# gcv = GridSearchCV(lr, param_grid=params,cv=kfold,
#                    scoring='f1_macro')
### Tuning with ROC-AUC
# gcv = GridSearchCV(lr, param_grid=params,cv=kfold,
#                    scoring='roc_auc')
### Tuning with log loss
gcv = GridSearchCV(lr, param_grid=params,cv=kfold,
                    scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

pd_cv = pd.DataFrame(gcv.cv_results_)

### Listing the param keywords
print(lr.get_params())

#################### Bankruptcy ############################
brupt = pd.read_csv("Bankruptcy.csv", index_col=0)
X = brupt.drop(['D', 'YR'], axis=1)
y = brupt['D']

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
params = {'penalty': ['l1', 'l2', 'elasticnet', None],
          'l1_ratio': np.linspace(0,1,5),
          'solver':['lbfgs','liblinear',
                   'newton-cg','newton-cholesky','sag','saga']}


lr = LogisticRegression()

#gcv = GridSearchCV(lr, param_grid=params,cv=kfold)
### Tuning with ROC-AUC
gcv = GridSearchCV(lr, param_grid=params,cv=kfold,
                    scoring='roc_auc')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

pd_cv = pd.DataFrame(gcv.cv_results_)

#### Fit the model with best params on whole dataset
bm = LogisticRegression(l1_ratio=0.0, penalty='l1',
                        solver='liblinear+')
bm.fit(X, y)

#### unlabelled dataset
tst = pd.read_csv("testBankruptcy.csv", index_col=0)

#### Inferencing: Predicting on unlabelled data
predictions = bm.predict(tst)
print(predictions)

#OR

b_model = gcv.best_estimator_
predictions = b_model.predict(tst)
print(predictions)
