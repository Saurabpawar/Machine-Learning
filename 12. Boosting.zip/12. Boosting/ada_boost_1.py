import pandas as pd 
from sklearn.ensemble import AdaBoostClassifier
import matplotlib.pyplot as plt 
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import GridSearchCV
import numpy as np 

hr = pd.read_csv("HR_comma_sep.csv")
dum_hr = pd.get_dummies(hr, drop_first=True)
X = dum_hr.drop('left', axis=1)
y = dum_hr['left']

ada = AdaBoostClassifier(random_state=23)
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)

params={'n_estimators':[25,50,75,100]}
gcv = GridSearchCV(ada, param_grid=params, cv=kfold, verbose=3,
                   scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

################### Boston ##############################
from sklearn.model_selection import KFold 
from sklearn.ensemble import AdaBoostRegressor

boston = pd.read_csv("Boston.csv")
X = boston.drop('medv', axis=1)
y = boston['medv']

ada = AdaBoostRegressor(random_state=23)
kfold = KFold(n_splits=5, shuffle=True, random_state=23)

params={'n_estimators':[25,50,75,100]}
gcv = GridSearchCV(ada, param_grid=params, cv=kfold, verbose=3)
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)
