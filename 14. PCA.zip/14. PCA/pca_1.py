import pandas as pd 
import numpy as np 
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

milk = pd.read_csv("milk.csv", index_col=0)
scaler = StandardScaler()
m_scaled = scaler.fit_transform(milk)

prcomp = PCA()
comps = prcomp.fit_transform(m_scaled)
print(milk.shape)
print(comps.shape)

df_comps = pd.DataFrame(comps,
                        columns=['PC1','PC2',
                                 'PC3','PC4'],
                        index=milk.index)

print(df_comps.var())
print(prcomp.explained_variance_)
tot_var = np.sum(prcomp.explained_variance_)
prop_var = np.array(prcomp.explained_variance_)/tot_var
print(prop_var)
per_var = prop_var*100
print(per_var)
print("%age var explained by 1st two PCs:",77.57590469+17.74794969)
print(prcomp.explained_variance_ratio_)

############ with Pipeline #####################
from sklearn.pipeline import Pipeline

scaler = StandardScaler()
prcomp = PCA()

pipe = Pipeline([('SCL',scaler),('PCA', prcomp)])

comps = pipe.fit_transform(milk)
df_comps = pd.DataFrame(comps,
                        columns=['PC1','PC2',
                                 'PC3','PC4','PC5'],
                        index=milk.index)

print(prcomp.explained_variance_)
print(prcomp.explained_variance_ratio_)
print(prcomp.explained_variance_ratio_*100)

cum_sum = np.cumsum(prcomp.explained_variance_ratio_*100)
print(cum_sum)

###################### PCA biplot ###################
import matplotlib.pyplot as plt
from pca import pca
model = pca()

milk = pd.read_csv("milk.csv", index_col=0)

m_scaled = scaler.fit_transform(milk)
results = model.fit_transform(m_scaled,col_labels=milk.columns,
                              row_labels=list(milk.index))
model.biplot(label=True,legend=True)
for i in np.arange(0, milk.shape[0] ):
    plt.text(comps[i,0], comps[i,1], list(milk.index)[i])
plt.show()




