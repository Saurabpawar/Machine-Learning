import pandas as pd
import matplotlib.pyplot as plt
from numpy import sqrt
from sklearn.metrics import mean_squared_error as mse

df = pd.read_csv("monthly-milk-production-pounds-p.csv")
df.head()

y = df['Milk']


y_train = df['Milk'][:-12]
y_test = df['Milk'][-12:]

############ ACF ########################
from statsmodels.graphics.tsaplots import plot_acf
plot_acf(df['Milk'], lags=10)
plt.show()


########################## ARIMA ##############################
from statsmodels.tsa.arima.model import ARIMA
# train 
model = ARIMA(y_train,order=(3,1,1))
model_fit = model.fit()

print('Coefficients: %s' % model_fit.params)
# make predictions
predictions = model_fit.predict(start=len(y_train), 
                                end=len(y_train)+len(y_test)-1, 
                                dynamic=False)
    
error = mse(y_test, predictions)
print('Test RMSE: %.3f' % sqrt(error))
# plot results
plt.plot(y_test, label="Test")
plt.plot(predictions, color='red', label="Forecast")
plt.legend(loc='best')
plt.show()

# plot
y_train.plot(color="blue", label="Train")
y_test.plot(color="pink", label="Test")
predictions.plot(color="purple", label="Forecast")
plt.legend(loc='best')
plt.show()

######## Auto ARIMA ################
from pmdarima.arima import auto_arima
model = auto_arima(y_train, trace=True,
                   error_action='ignore', 
                   suppress_warnings=True)

forecast = model.predict(n_periods=len(y_test))
forecast = pd.DataFrame(forecast,index = y_test.index,
                        columns=['Prediction'])

rms = sqrt(mse(y_test, forecast))
print('Test RMSE: %.3f' % rms)


# plot results
plt.plot(y_test, label="Test")
plt.plot(forecast, color='red', label="Forecast")
plt.legend(loc='best')
plt.show()

# plot
y_train.plot(color="blue", label="Train")
y_test.plot(color="pink", label="Test")
plt.plot(forecast, label='Prediction',color="purple")
plt.legend(loc='best')
plt.show()


########### SARIMA ########################
model = auto_arima(y_train, trace=True,
                   error_action='ignore', 
                   suppress_warnings=True,
                   seasonal=True,m=12)

forecast = model.predict(n_periods=len(y_test))
forecast = pd.DataFrame(forecast,index = y_test.index,
                        columns=['Prediction'])

rms = sqrt(mse(y_test, forecast))
print('Test RMSE: %.3f' % rms)


# plot results
plt.plot(y_test, label="Test")
plt.plot(forecast, color='red', label="Forecast")
plt.legend(loc='best')
plt.show()

# plot
y_train.plot(color="blue", label="Train")
y_test.plot(color="pink", label="Test")
plt.plot(forecast, label='Prediction',color="purple")
plt.legend(loc='best')
plt.show()



