import pandas as pd 
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import matplotlib.pyplot as plt 
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score , mean_squared_error
import numpy as np

boston = pd.read_csv("Boston.csv")
X = boston.drop('medv', axis=1).values
y = boston['medv'].values
X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               random_state=23)
knn = KNeighborsRegressor(n_neighbors=3)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)
print(r2_score(y_test, y_pred))

### Scaling

knn = KNeighborsRegressor(n_neighbors=3)
std_scaler = StandardScaler()
pipe = Pipeline([('SCL', std_scaler), ('KNN', knn)])
pipe.fit(X_train, y_train)
y_pred = pipe.predict(X_test)
print(r2_score(y_test, y_pred))

mm_scaler = MinMaxScaler()
pipe = Pipeline([('SCL', mm_scaler), ('KNN', knn)])
pipe.fit(X_train, y_train)
y_pred = pipe.predict(X_test)
print(r2_score(y_test, y_pred))

#####################################################
from sklearn.model_selection import GridSearchCV 
from sklearn.model_selection import KFold 
knn = KNeighborsRegressor()
kfold = KFold(n_splits=5, shuffle=True,
                        random_state=23)
print(knn.get_params())
params = {'n_neighbors': np.arange(1,31)}
gcv = GridSearchCV(knn, param_grid=params,
                   cv=kfold)
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

### Using Pipeline
pipe_std = Pipeline([('SCL', std_scaler), ('KNN', knn)])
print(pipe_std.get_params())
params = {'KNN__n_neighbors': np.arange(1,31)}
gcv = GridSearchCV(pipe_std, param_grid=params, cv=kfold)
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

pipe_mm = Pipeline([('SCL', mm_scaler), ('KNN', knn)])
params = {'KNN__n_neighbors':np.arange(1,31)}
gcv = GridSearchCV(pipe_mm, param_grid=params, cv=kfold)
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)
