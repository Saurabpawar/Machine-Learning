import numpy as np 
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
x_trn = np.array([[10,0.1],
              [8, 0.7],
              [11,0.1]])
x_tst = np.array([[10],[0.8]])

std_scaler = StandardScaler()
std_scaler.fit(x_trn) # will calculate mean & sd of all cols
std_scaler.transform(x_trn) # will transform
print(std_scaler.mean_) # get means of all cols
print(std_scaler.scale_) # get std deviations of all cols


mm_scaler = MinMaxScaler()
mm_scaler.fit(x_trn) # will calculate mean & sd of all cols
mm_scaler.transform(x_trn) # will transform
print(mm_scaler.data_min_) # get min of all cols
print(mm_scaler.data_max_) # get max of all cols


