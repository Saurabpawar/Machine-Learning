import pandas as pd 
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import ConfusionMatrixDisplay
import numpy as np
hr = pd.read_csv("HR_comma_sep.csv")
dum_hr = pd.get_dummies(hr, drop_first=True)
X = dum_hr.drop('left', axis=1).values
y = dum_hr['left'].values
X_train, X_test, y_train, y_test = train_test_split(X,y, 
                               test_size=0.3,
                               stratify=y,
                               random_state=23)
### Using Standard Scaler
std_scaler = StandardScaler()
std_scaler.fit(X_train)
X_scl_trn = std_scaler.transform(X_train)

knn = KNeighborsClassifier(n_neighbors=1)
knn.fit(X_scl_trn, y_train)

X_scl_tst = std_scaler.transform(X_test)
y_pred = knn.predict(X_scl_tst)
y_pred_prob = knn.predict_proba(X_scl_tst)
print(accuracy_score(y_test, y_pred))
print(log_loss(y_test, y_pred_prob))

### Using MinMax Scaler
from sklearn.preprocessing import MinMaxScaler
mm_scaler = MinMaxScaler()
mm_scaler.fit(X_train)
X_scl_trn = mm_scaler.transform(X_train)

knn = KNeighborsClassifier(n_neighbors=1)
knn.fit(X_scl_trn, y_train)

X_scl_tst = mm_scaler.transform(X_test)
y_pred = knn.predict(X_scl_tst)
y_pred_prob = knn.predict_proba(X_scl_tst)
print(accuracy_score(y_test, y_pred))
print(log_loss(y_test, y_pred_prob))

################ Pipeline ###################
from sklearn.pipeline import Pipeline
knn = KNeighborsClassifier(n_neighbors=1)
std_scaler = StandardScaler()
pipe = Pipeline([('SCL', std_scaler), ('KNN', knn)])
pipe.fit(X_train, y_train)
y_pred = pipe.predict(X_test)
print(accuracy_score(y_test, y_pred))

mm_scaler = MinMaxScaler()
pipe = Pipeline([('SCL', mm_scaler), ('KNN', knn)])
pipe.fit(X_train, y_train)
y_pred = pipe.predict(X_test)
print(accuracy_score(y_test, y_pred))

#####################################################
from sklearn.model_selection import GridSearchCV 
from sklearn.model_selection import StratifiedKFold 
knn = KNeighborsClassifier()
kfold = StratifiedKFold(n_splits=5, shuffle=True,
                        random_state=23)
print(knn.get_params())
params = {'n_neighbors': [1,3,5,7,9,11,13,15,17]}
gcv = GridSearchCV(knn, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

### Using Pipeline
pipe_std = Pipeline([('SCL', std_scaler), ('KNN', knn)])
print(pipe_std.get_params())
params = {'KNN__n_neighbors': [1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31]}
gcv = GridSearchCV(pipe_std, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

pipe_mm = Pipeline([('SCL', mm_scaler), ('KNN', knn)])
params = {'KNN__n_neighbors':[1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31]}
gcv = GridSearchCV(pipe_mm, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)


#################### Bankruptcy ############################
brupt = pd.read_csv("Bankruptcy.csv", index_col=0)
X = brupt.drop(['D', 'YR'], axis=1)
y = brupt['D']

pipe_std = Pipeline([('SCL', std_scaler), ('KNN', knn)])
print(pipe_std.get_params())
params = {'KNN__n_neighbors': [1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31]}
gcv = GridSearchCV(pipe_std, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)

pipe_mm = Pipeline([('SCL', mm_scaler), ('KNN', knn)])
params = {'KNN__n_neighbors':[1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31]}
gcv = GridSearchCV(pipe_mm, param_grid=params,
                   cv=kfold, scoring='neg_log_loss')
gcv.fit(X, y)
print(gcv.best_params_)
print(gcv.best_score_)