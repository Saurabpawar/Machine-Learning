import pandas as pd 
import numpy as np 
from sklearn.linear_model import Ridge , Lasso
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

boston = pd.read_csv("Boston.csv")

bs_train, bs_test = train_test_split(boston, test_size=0.3,
                                     random_state=23)
X_train = bs_train.drop('medv', axis=1)
y_train = bs_train['medv']
X_test = bs_test.drop('medv', axis=1)
y_test = bs_test['medv']

alphas = np.linspace(0.001, 15, 20)
scores = []
for v in alphas:
    ridge = Ridge(alpha=v)
    ridge.fit(X_train, y_train)
    y_pred = ridge.predict(X_test)
    scr = r2_score(y_test, y_pred) 
    scores.append(scr)
    #print("Alpha =", v, "R2 =", scr)

i_max = np.argmax(scores)
print("Best alpha =", alphas[i_max])
print("Best score =", scores[i_max])

################################################
sals = pd.read_csv("Salaries.csv")
dum_sals = pd.get_dummies(sals, drop_first=True)

sal_train, sal_test = train_test_split(dum_sals, test_size=0.3,
                                     random_state=23)
X_train = sal_train.drop('salary', axis=1)
y_train = sal_train['salary']
X_test = sal_test.drop('salary', axis=1)
y_test = sal_test['salary']

alphas = np.linspace(0.001, 15, 20)
scores = []
for v in alphas:
    ridge = Ridge(alpha=v)
    ridge.fit(X_train, y_train)
    y_pred = ridge.predict(X_test)
    scr = r2_score(y_test, y_pred) 
    scores.append(scr)

i_max = np.argmax(scores)
print("Best alpha =", alphas[i_max])
print("Best score =", scores[i_max])

plt.plot(alphas, scores)
plt.scatter(alphas, scores, c='red')
plt.xlabel("Alpha")
plt.ylabel("Score")
plt.show()


