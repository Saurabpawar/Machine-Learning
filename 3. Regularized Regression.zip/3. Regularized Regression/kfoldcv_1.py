import pandas as pd 
import numpy as np 
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge, Lasso
from sklearn.linear_model import ElasticNet 
import matplotlib.pyplot as plt 
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score

boston = pd.read_csv("Boston.csv")
X = boston.drop('medv', axis=1)
y = boston['medv']
kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
lr = LinearRegression()
result = cross_val_score(lr, X, y, cv=kfold)
print("R2 =", np.mean(result))

#### Ridge

kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
alphas = np.linspace(0.001, 15, 20)

scores = []
for v in alphas:
    ridge = Ridge(alpha=v)
    scr = np.mean(cross_val_score(ridge,
                                  X, y, cv=kfold))
    scores.append(scr)

i_max = np.argmax(scores)
print("Best alpha =", alphas[i_max])
print("Best score =", scores[i_max])

#### Lasso

kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
alphas = np.linspace(0.001, 15, 20)

scores = []
for v in alphas:
    lasso = Lasso(alpha=v)
    scr = np.mean(cross_val_score(lasso,
                                  X, y, cv=kfold))
    scores.append(scr)

i_max = np.argmax(scores)
print("Best alpha =", alphas[i_max])
print("Best score =", scores[i_max])

### Elastic Net
alphas = np.linspace(0.001, 15, 20)
l1_s = np.linspace(0,1,10)
scores = []
params = []
for v in alphas:
    for l1 in l1_s:
        elast = ElasticNet(alpha=v, l1_ratio=l1)
        scr = np.mean(cross_val_score(elast,
                                  X, y, cv=kfold)) 
        params.append({'alpha':v,'l1_ratio': l1})
        scores.append(scr)

i_max = np.argmax(scores)
print("Best alpha =", params[i_max])
print("Best score =", scores[i_max])

