import pandas as pd 
import numpy as np 
from sklearn.linear_model import  Lasso
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
os.chdir("F:\CDAC DBDA\Advance Analytics\Datasets")
boston = pd.read_csv("Boston.csv")

bs_train, bs_test = train_test_split(boston, test_size=0.3,
                                     random_state=23)

print(bs_test)
X_train = bs_train.drop('medv', axis=1)
y_train = bs_train['medv']
X_test = bs_test.drop('medv', axis=1)
y_test = bs_test['medv']
 

#or
'''
x = boston.drop('medv', axis=1)
y = boston['medv']
x_train,x_test,y_train,y_test = train_test_split(x,y, test_size=0.30,random_state=23)
'''


alphas = np.linspace(0.001, 15, 20)
scores = []
for v in alphas:
    lasso = Lasso(alpha=v)
    lasso.fit(X_train, y_train)
    y_pred = lasso.predict(X_test)
    scr = r2_score(y_test, y_pred) 
    scores.append(scr)
    #print("Alpha =", v, "R2 =", scr)

i_max = np.argmax(scores)
print("Best alpha =", alphas[i_max])
print("Best score =", scores[i_max])

################################################
sals = pd.read_csv("Salaries.csv")
dum_sals = pd.get_dummies(sals, drop_first=True)

sal_train, sal_test = train_test_split(dum_sals, test_size=0.3,
                                     random_state=23)
X_train = sal_train.drop('salary', axis=1)
y_train = sal_train['salary']
X_test = sal_test.drop('salary', axis=1)
y_test = sal_test['salary']

alphas = np.linspace(0.001, 15, 20)
scores = []
for v in alphas:
    lasso = Lasso(alpha=v)
    lasso.fit(X_train, y_train)
    y_pred = lasso.predict(X_test)
    scr = r2_score(y_test, y_pred) 
    scores.append(scr)
    
i_max = np.argmax(scores)
print("Best alpha =", alphas[i_max])
print("Best score =", scores[i_max])