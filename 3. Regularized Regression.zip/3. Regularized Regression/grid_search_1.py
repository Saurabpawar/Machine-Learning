import pandas as pd 
import numpy as np 
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge, Lasso
from sklearn.linear_model import ElasticNet 
import matplotlib.pyplot as plt 
from sklearn.model_selection import GridSearchCV, cross_val_score
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score

boston = pd.read_csv("Boston.csv")
X = boston.drop('medv', axis=1)
y = boston['medv']
kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
lr = LinearRegression()
result = cross_val_score(lr, X, y, cv=kfold)
print("R2 =", np.mean(result))

#### Ridge

kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
alphas = np.linspace(0.001, 15, 20)
ridge = Ridge()
params = {'alpha': alphas}
gcv = GridSearchCV(ridge, param_grid=params,
                   cv=kfold)
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)

#### Lasso

kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
alphas = np.linspace(0.001, 15, 20)
params = {'alpha': alphas}
lasso = Lasso()
gcv = GridSearchCV(lasso, param_grid=params,
                   cv=kfold)
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)

### Elastic Net
alphas = np.linspace(0.001, 15, 20)
l1_s = np.linspace(0,1,10)
params = {'alpha': alphas,
          'l1_ratio': l1_s}
elast = ElasticNet()
gcv = GridSearchCV(elast, param_grid=params,
                   cv=kfold)
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)

############## Salaries
sals = pd.read_csv("Salaries.csv")
dum_sals = pd.get_dummies(sals, drop_first=True)
X = dum_sals.drop('salary', axis=1)
y = dum_sals['salary']

kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
lr = LinearRegression()
result = cross_val_score(lr, X, y, cv=kfold)
print("R2 =", np.mean(result))

#### Ridge

kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
alphas = np.linspace(0.001, 15, 20)
ridge = Ridge()
params = {'alpha': alphas}
gcv = GridSearchCV(ridge, param_grid=params,
                   cv=kfold)
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)

#### Lasso

kfold = KFold(n_splits=5, shuffle=True, 
              random_state=23)
alphas = np.linspace(0.001, 15, 20)
params = {'alpha': alphas}
lasso = Lasso()
gcv = GridSearchCV(lasso, param_grid=params,
                   cv=kfold)
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)
## Grid Results in DataFrame
pd_cv = pd.DataFrame( gcv.cv_results_ )

### Elastic Net
alphas = np.linspace(0.001, 15, 20)
l1_s = np.linspace(0,1,10)
params = {'alpha': alphas,
          'l1_ratio': l1_s}
elast = ElasticNet()
gcv = GridSearchCV(elast, param_grid=params,
                   cv=kfold)
gcv.fit(X,y)
print(gcv.best_params_)
print(gcv.best_score_)










